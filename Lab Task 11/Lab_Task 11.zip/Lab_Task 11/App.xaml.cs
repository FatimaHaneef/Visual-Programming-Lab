﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace vp_lab_task10
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
